import pandas as pd
import yaml
import os
from sqlalchemy import create_engine
import requests
import redis
import json

CONFIG_PATH = "./config/config.yaml"

def load_config():
    with open(CONFIG_PATH, "r") as file:
        return yaml.safe_load(file)

def fetch_from_file(path):
    print(f"Loading from file: {path}")
    return pd.read_csv(path, parse_dates=["entry_time"])

def fetch_from_db(connection_string, query):
    print("Fetching from DB...")
    engine = create_engine(connection_string)
    return pd.read_sql(query, engine, parse_dates=["entry_time"])

def fetch_from_api(endpoint):
    print("Fetching from API...")
    response = requests.get(endpoint)
    response.raise_for_status()
    data = response.json()
    return pd.DataFrame(data)

def fetch_from_cache(host, port, key):
    print("Fetching from cache...")
    r = redis.Redis(host=host, port=port, decode_responses=True)
    cached_data = r.get(key)
    if cached_data:
        return pd.DataFrame(json.loads(cached_data))
    else:
        raise ValueError("No data found in cache for the given key.")

def fetch_data():
    config = load_config()
    source_type = config["source"]["type"]

    if source_type == "file":
        return fetch_from_file(config["source"]["path"])
    elif source_type == "db":
        return fetch_from_db(config["source"]["connection_string"], config["source"]["query"])
    elif source_type == "api":
        return fetch_from_api(config["source"]["endpoint"])
    elif source_type == "cache":
        return fetch_from_cache(
            config["source"]["host"],
            config["source"]["port"],
            config["source"]["key"]
        )
    else:
        raise ValueError(f"Unsupported source type: {source_type}")

if _name_ == "_main_":
    df = fetch_data()
    print(f"Fetched {len(df)} records")
    df.to_csv("./data/fetched_data.csv", index=False)
    print("Saved to ./data/fetched_data.csv")