from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.api.routes import router
from app.core.preprocess import preprocess_data  # Runs without arguments

# ✅ Initialize FastAPI app
app = FastAPI(
    title="GenAI Trade Outage Impact Predictor",
    description="Real-time prediction of trades impacted during outages using LSTM, historical trade data, and economic signals.",
    version="1.0.0"
)

# ✅ Mount static files (for images/plots)
app.mount("/static", StaticFiles(directory="static"), name="static")

# ✅ Enable CORS for frontend use (Streamlit, JS, etc.)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # ✅ Adjust to specific domains in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Run preprocessing automatically at startup
@app.on_event("startup")
def run_preprocessing():
    print("⚙️ Running preprocessing on startup...")
    preprocess_data()

# ✅ Register all API endpoints
app.include_router(router)
