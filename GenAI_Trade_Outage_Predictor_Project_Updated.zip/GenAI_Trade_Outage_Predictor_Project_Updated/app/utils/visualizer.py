# app/utils/visualizer.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def plot_hourly_trend(df: pd.DataFrame, output_path: str = "./static/hourly_trend.png"):
    df["entry_hour"] = pd.to_datetime(df["entry_time"]).dt.hour
    hourly = df.groupby(["entry_hour", "region"]).size().reset_index(name="count")
    
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=hourly, x="entry_hour", y="count", hue="region", marker="o")
    plt.title("Hourly Trade Volume by Region")
    plt.xlabel("Hour")
    plt.ylabel("Trade Count")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_buy_sell_distribution(df: pd.DataFrame, output_path: str = "./static/buy_sell.png"):
    buy_sell = df.groupby(["buy_sell"]).size().reset_index(name="count")
    
    plt.figure(figsize=(6, 4))
    sns.barplot(data=buy_sell, x="buy_sell", y="count", palette="Set2")
    plt.title("Buy vs Sell Trades")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_prediction_vs_actual(y_true, y_pred, output_path="./static/pred_vs_actual.png"):
    plt.figure(figsize=(10, 5))
    plt.plot(y_true, label="Actual")
    plt.plot(y_pred, label="Predicted", linestyle="--")
    plt.legend()
    plt.title("Prediction vs Actual Trade Impact")
    plt.xlabel("Time Step")
    plt.ylabel("Trade Count")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_volume_spike(df: pd.DataFrame, output_path: str = "./static/volume_spike.png"):
    df["hour"] = pd.to_datetime(df["entry_time"]).dt.floor("H")
    volume = df.groupby("hour")["volume"].sum().reset_index()
    
    plt.figure(figsize=(10, 5))
    plt.plot(volume["hour"], volume["volume"], marker="o", color="crimson")
    plt.title("Trade Volume Spike Over Time")
    plt.xlabel("Time (Hour)")
    plt.ylabel("Total Volume")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()