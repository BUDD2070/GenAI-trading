import os
import openai
from app.schemas.trade_schema import TradeQueryRequest
from datetime import datetime
from ast import literal_eval
import re

openai.api_key = os.getenv("OPENAI_API_KEY")

def parse_date(date_str: str) -> datetime:
    """
    Converts a string like 'Apr-24' or '2025-04-01' to a datetime object.
    """
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        try:
            return datetime.strptime(date_str, "%b-%y")
        except ValueError:
            return None

def handle_natural_language_query(query: str) -> TradeQueryRequest:
    try:
        system_prompt = (
            "You are a helpful assistant that extracts query parameters from trade-related user questions. "
            "Identify and return the following keys in a Python dictionary: "
            "asset_class, sub_asset_class, region (optional), side (buy/sell, optional), "
            "start_date, and end_date. Dates should be in either 'Apr-24' or '2025-04-01' format."
        )

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query}
            ]
        )

        content = response.choices[0].message['content'].strip()

        # Safer parsing of stringified dict
        extracted = literal_eval(content) if isinstance(content, str) else content

        # Extract and parse fields
        asset_class = extracted.get("asset_class")
        sub_asset_class = extracted.get("sub_asset_class")
        region = extracted.get("region")
        side = extracted.get("side")
        start_date = parse_date(extracted.get("start_date")) if extracted.get("start_date") else None
        end_date = parse_date(extracted.get("end_date")) if extracted.get("end_date") else None

        # Mandatory checks
        if not all([asset_class, sub_asset_class, start_date, end_date]):
            raise ValueError("Missing required fields: asset_class, sub_asset_class, start_date, or end_date.")

        return TradeQueryRequest(
            asset_class=asset_class,
            sub_asset_class=sub_asset_class,
            region=region,
            side=side,
            start_date=start_date,
            end_date=end_date
        )

    except Exception as e:
        raise ValueError(f"Failed to process query: {str(e)}")