# ✅ app/core/lstm_model.py

import os
import numpy as np
import pandas as pd
import pickle
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import EarlyStopping

MODEL_PATH = "app/models/lstm_model.keras"
SCALER_ENCODER_PATH = "app/models/scaler_encoders.pkl"


def preprocess_for_training(df):
    df = df.copy()
    features = ["asset_class", "sub_asset_class", "region", "side", "hour"]
    target = "volume"

    label_encoders = {}
    for col in features:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        label_encoders[col] = le

    scaler = MinMaxScaler()
    df[[target]] = scaler.fit_transform(df[[target]])

    X = df[features].values.reshape((-1, 1, len(features)))
    y = df[[target]].values

    return X, y, scaler, label_encoders


def train_lstm_model(df):
    X, y, scaler, label_encoders = preprocess_for_training(df)

    model = Sequential([
        LSTM(50, activation='relu', input_shape=(X.shape[1], X.shape[2])),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    model.fit(X, y, epochs=10, batch_size=32, callbacks=[EarlyStopping(patience=2)])

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    model.save(MODEL_PATH)

    with open(SCALER_ENCODER_PATH, 'wb') as f:
        pickle.dump({'scaler': scaler, 'encoders': label_encoders}, f)

    return model


def load_lstm_model():
    model = load_model(MODEL_PATH, compile=False)
    with open(SCALER_ENCODER_PATH, 'rb') as f:
        data = pickle.load(f)
    return model, data['scaler'], data['encoders']