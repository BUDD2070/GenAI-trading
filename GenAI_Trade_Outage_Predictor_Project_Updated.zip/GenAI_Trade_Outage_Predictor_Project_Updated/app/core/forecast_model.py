import numpy as np
import pandas as pd
import pickle
import json
from fastapi import HTTPException
from joblib import load

MODEL_PATH = "app/models/lightgbm_model.pkl"
CATEGORIES_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\categories.json"
VOLUME_SCALER_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\volume_scaler.pkl"

def forecast_trades(request):
    try:
        # Load model
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)

        # Load scaler
        scaler = load(VOLUME_SCALER_PATH)

        # Load categories
        with open(CATEGORIES_PATH, "r") as f:
            categories = json.load(f)

        def normalize_cat_value(x):
            if x is None:
                return []
            if isinstance(x, list):
                return [str(v).strip().lower() for v in x]
            return [str(x).strip().lower()]

        asset_classes = normalize_cat_value(getattr(request, "asset_class", None))
        sub_assets = normalize_cat_value(getattr(request, "sub_asset_class", None))
        regions = normalize_cat_value(getattr(request, "region", None))
        sides = normalize_cat_value(getattr(request, "buy_sell", None))

        # Use all known categories if not provided or invalid
        asset_classes = [a for a in asset_classes if a in categories["asset_class"]] or categories["asset_class"]
        sub_assets = [s for s in sub_assets if s in categories["sub_asset_class"]] or categories["sub_asset_class"]
        regions = [r for r in regions if r in categories["region"]] or categories["region"]
        sides = [s for s in sides if s in categories["side"]] or categories["side"]

        # Time range
        hours = pd.date_range(request.start_date, request.end_date, freq="h")

        rows = []
        for t in hours:
            for a in asset_classes:
                for s in sub_assets:
                    for r in regions:
                        for side in sides:
                            rows.append({
                                "asset_class": a,
                                "sub_asset_class": s,
                                "region": r,
                                "side": side,
                                "hour": t.hour,
                                "timestamp": t
                            })

        df = pd.DataFrame(rows)

        # Ensure categories
        for col in ["asset_class", "sub_asset_class", "region", "side"]:
            df[col] = pd.Categorical(df[col], categories=categories[col])

        features = ["asset_class", "sub_asset_class", "region", "side", "hour"]

        # Predict (still in normalized scale)
        df["forecasted_volume"] = model.predict(df[features])

        # Inverse transform (denormalize)
        # Create dummy 2-column array for inverse_transform
        dummy = np.zeros((len(df), 2))
        dummy[:, 0] = df["forecasted_volume"]
        df["forecasted_volume"] = scaler.inverse_transform(dummy)[:, 0]
        df["forecasted_volume"] = np.maximum(0, df["forecasted_volume"].round().astype(int))

        # Grouping
        group_by = getattr(request, "group_by", []) or []
        group_by_keys = [g if g != "buy_sell" else "side" for g in group_by]
        granularity = getattr(request, "granularity", "hourly")

        if granularity == "total":
            if group_by_keys:
                grouped = df.groupby(group_by_keys, observed=False)["forecasted_volume"].sum().reset_index()
                return grouped.to_dict(orient="records")
            else:
                return {"total_forecasted_volume": int(df["forecasted_volume"].sum())}
        else:
            df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
            if group_by_keys:
                grouped = df.groupby(["timestamp"] + group_by_keys, observed=False)["forecasted_volume"].sum().reset_index()
            else:
                grouped = df[["timestamp", "forecasted_volume"]]
            return grouped.to_dict(orient="records")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Forecasting failed: {str(e)}")