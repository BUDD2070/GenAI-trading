import pandas as pd
import numpy as np
import os
import json
from sklearn.preprocessing import MinMaxScaler
from scipy import stats
from joblib import dump

# Default paths
DEFAULT_RAW_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\app\config\data\trade_history.csv"
DEFAULT_PREPROCESSED_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\preprocessed.csv"
CATEGORIES_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\categories.json"
VOLUME_SCALER_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\volume_scaler.pkl"

def preprocess_data(input_path: str = DEFAULT_RAW_PATH, output_path: str = DEFAULT_PREPROCESSED_PATH):
    print("📥 Preprocessing started...")

    # Load raw CSV with date parsing
    df = pd.read_csv(input_path, parse_dates=["entry_date"])

    # ✅ 1. Keep only confirmed trades
    df = df[df["status"].str.lower() == "confirmed"]

    # ✅ 2. Drop trades with parent_id if exists
    if "parent_id" in df.columns:
        df = df[df["parent_id"].isnull()]

    # ✅ 3. Drop rows with nulls in required columns
    required = ["entry_date", "region", "asset_class", "sub_asset_class", "buy_sell", "volume", "price"]
    df.dropna(subset=required, inplace=True)

    # ✅ 4. Remove outliers using z-score on volume and price
    df["volume_z"] = np.abs(stats.zscore(df["volume"]))
    df["price_z"] = np.abs(stats.zscore(df["price"]))
    df = df[(df["volume_z"] < 3) & (df["price_z"] < 3)]
    df.drop(columns=["volume_z", "price_z"], inplace=True)

    # ✅ 5. Drop unused columns if they exist
    df.drop(columns=["trade_id", "status", "parent_id"], errors="ignore", inplace=True)

    # ✅ 6. Rename buy_sell to side
    df.rename(columns={"buy_sell": "side"}, inplace=True)

    # ✅ 7. Normalize text columns (fillna, lowercase, strip)
    for col in ["region", "asset_class", "sub_asset_class", "side"]:
        df[col] = df[col].fillna("").astype(str).str.strip().str.lower()

    # ✅ 8. Normalize volume and price using MinMaxScaler
    scaler = MinMaxScaler()
    df[["volume", "price"]] = scaler.fit_transform(df[["volume", "price"]])

    # Save volume scaler for use during prediction inverse-transform
    dump(scaler, VOLUME_SCALER_PATH)

    # ✅ 9. Add time-based features
    df["entry_time"] = df["entry_date"]
    df["hour"] = df["entry_time"].dt.hour
    df["day_of_week"] = df["entry_time"].dt.dayofweek
    df["month"] = df["entry_time"].dt.month
    df.drop(columns=["entry_date"], inplace=True)

    # ✅ 10. Save preprocessed data to CSV
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)

    # ✅ 11. Save category levels for categorical columns to JSON for later use
    categories = {}
    for col in ["asset_class", "sub_asset_class", "region", "side"]:
        categories[col] = sorted(df[col].unique().tolist())

    os.makedirs(os.path.dirname(CATEGORIES_PATH), exist_ok=True)
    with open(CATEGORIES_PATH, "w") as f:
        json.dump(categories, f)

    print(f"✅ Preprocessing complete. Saved to {output_path}")
    print(f"✅ Categories saved to {CATEGORIES_PATH}")
    print(f"✅ Volume scaler saved to {VOLUME_SCALER_PATH}")

    return df, scaler