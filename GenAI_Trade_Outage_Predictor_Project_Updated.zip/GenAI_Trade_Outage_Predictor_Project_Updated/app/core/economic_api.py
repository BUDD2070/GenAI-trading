# app/core/economic_api.py

import requests
import pandas as pd
from datetime import datetime

def fetch_fred_event_series(series_id: str, api_key: str, start_date="2023-01-01") -> pd.DataFrame:
    url = (
        f"https://api.stlouisfed.org/fred/series/observations?"
        f"series_id={series_id}&api_key={api_key}&file_type=json&observation_start={start_date}"
    )
    response = requests.get(url)
    data = response.json().get("observations", [])

    df = pd.DataFrame(data)
    df["date"] = pd.to_datetime(df["date"])
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df[["date", "value"]]

def enrich_with_economic_events(trade_df: pd.DataFrame, api_key: str) -> pd.DataFrame:
    # Example: Get CPI index from FRED
    cpi = fetch_fred_event_series("CPIAUCNS", api_key)
    gdp = fetch_fred_event_series("GDP", api_key)

    # Merge CPI and GDP into trade_df
    trade_df["entry_time"] = pd.to_datetime(trade_df["entry_time"])
    trade_df = trade_df.merge(cpi.rename(columns={"value": "cpi"}), how="left", left_on="entry_time", right_on="date")
    trade_df = trade_df.merge(gdp.rename(columns={"value": "gdp"}), how="left", left_on="entry_time", right_on="date")

    trade_df.drop(columns=["date_x", "date_y"], errors="ignore", inplace=True)
    trade_df.fillna(method="ffill", inplace=True)

    return trade_df