import pandas as pd
import yaml
import os

def load_config(path="app/config/config.yaml"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file not found: {path}")
    
    with open(path, "r") as file:
        config = yaml.safe_load(file)
        if "data_source" not in config or not config["data_source"].get("type"):
            raise ValueError("Missing or invalid 'data_source' config section.")
        return config

def load_data(config=None):
    if config is None:
        config = load_config()
    
    source = config.get("data_source", {})
    source_type = source.get("type")

    if source_type == "file":
        path = source.get("path")
        file_name = source.get("file_name")  # ✅ fixed: called get() correctly
        if not path or not file_name:
            raise ValueError("Missing 'path' or 'file_name' in config.")

        full_path = os.path.join(path, file_name)
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"File not found at: {full_path}")
        
        print(f"[FILE] Loading data from: {full_path}")
        return pd.read_csv(full_path)

    elif source_type == "db":
        import sqlalchemy
        engine = sqlalchemy.create_engine(source["connection_string"])
        query = source["query"]
        print("[DB] Executing query...")
        return pd.read_sql(query, con=engine)

    elif source_type == "api":
        import requests
        headers = source.get("headers", {})
        print(f"[API] Fetching from: {source['endpoint']}")
        response = requests.get(source["endpoint"], headers=headers)
        response.raise_for_status()
        return pd.DataFrame(response.json())

    elif source_type == "cache":
        import redis
        import json
        r = redis.Redis(host=source["host"], port=source["port"])
        data = r.get(source["key"])
        if not data:
            raise ValueError("No data found in cache")
        print("[CACHE] Data fetched from Redis")
        return pd.DataFrame(json.loads(data))

    else:
        raise ValueError(f"Unsupported source type: {source_type}")