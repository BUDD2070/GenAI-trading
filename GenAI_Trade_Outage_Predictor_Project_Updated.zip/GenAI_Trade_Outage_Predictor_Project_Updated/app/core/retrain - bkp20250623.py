import os
import sys
import traceback
from app.core import data_source, preprocess, lstm_model
from app.core.lstm_model import save_scaler_and_encoders

def retrain_pipeline():
    try:
        # ✅ Hardcoded full path to input trade history CSV
        input_path = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\app\config\data\trade_history.csv"
        output_path = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\preprocessed.csv"

        print("📥 Preprocessing data...")
        preprocessed_df = preprocess.preprocess_data(input_path=input_path, output_path=output_path)

        print("🧠 Training LSTM model...")
        model, scaler, label_encoders = lstm_model.train_model(preprocessed_df)

        print("✅ Model training completed and saved!")
        save_scaler_and_encoders(scaler, label_encoders)

    except Exception as e:
        print("❌ Error in retrain_pipeline:", str(e))
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    retrain_pipeline()