# app/core/retrain_pipeline.py

import os
import sys
import traceback
import pandas as pd
from app.core import preprocess
from app.core.train_lightgbm import train_model

RAW_FILE_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\app\config\data\trade_history.csv"
PREPROCESSED_FILE_PATH = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\data\preprocessed.csv"

def retrain_pipeline():
    try:
        print("📥 Preprocessing data...")
        df, _ = preprocess.preprocess_data(RAW_FILE_PATH, PREPROCESSED_FILE_PATH)

        print("🧠 Training LightGBM model...")
        train_model(df)

        print("✅ Model retraining and saving completed successfully.")

    except Exception as e:
        print("❌ Error in retrain_pipeline:", str(e))
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    retrain_pipeline()