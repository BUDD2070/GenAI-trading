import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

STATIC_DIR = "./static"
os.makedirs(STATIC_DIR, exist_ok=True)

def plot_hourly_trend(df: pd.DataFrame):
    df["hour"] = pd.to_datetime(df["entry_date"]).dt.hour
    hourly_counts = df.groupby("hour").size()

    plt.figure(figsize=(10, 5))
    sns.lineplot(x=hourly_counts.index, y=hourly_counts.values)
    plt.title("Hourly Trade Volume Trend")
    plt.xlabel("Hour")
    plt.ylabel("Number of Trades")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(f"{STATIC_DIR}/hourly_trend.png")
    plt.close()

def plot_buy_sell_distribution(df: pd.DataFrame):
    if "buy_sell" not in df.columns:
        return
    buy_sell_counts = df["buy_sell"].value_counts()

    plt.figure(figsize=(6, 4))
    sns.barplot(x=buy_sell_counts.index, y=buy_sell_counts.values)
    plt.title("Buy/Sell Distribution")
    plt.xlabel("Side")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(f"{STATIC_DIR}/buy_sell_distribution.png")
    plt.close()

def plot_volume_spike(df: pd.DataFrame):
    df["entry_date"] = pd.to_datetime(df["entry_date"]).dt.date
    daily_counts = df.groupby("entry_date").size()

    plt.figure(figsize=(10, 4))
    sns.lineplot(x=daily_counts.index, y=daily_counts.values)
    plt.title("Daily Trade Volume (Spike Detection)")
    plt.xlabel("Date")
    plt.ylabel("Trades")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{STATIC_DIR}/volume_spike.png")
    plt.close()

def plot_prediction_vs_actual(df: pd.DataFrame):
    if not {"predicted_trades", "actual_trades", "entry_date"}.issubset(df.columns):
        return

    df["entry_date"] = pd.to_datetime(df["entry_date"])
    df.sort_values("entry_date", inplace=True)

    plt.figure(figsize=(10, 5))
    sns.lineplot(data=df, x="entry_date", y="predicted_trades", label="Predicted")
    sns.lineplot(data=df, x="entry_date", y="actual_trades", label="Actual")
    plt.title("Prediction vs Actual Trades")
    plt.xlabel("Time")
    plt.ylabel("Trade Count")
    plt.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{STATIC_DIR}/prediction_vs_actual.png")
    plt.close()

def plot_trade_history(df: pd.DataFrame, granularity: str = "monthly") -> str:
    """
    Plot trade history over time based on granularity ('daily', 'monthly', or 'yearly').
    Returns the file path of the saved plot.
    """
    df["entry_date"] = pd.to_datetime(df["entry_date"])

    if granularity == "daily":
        df["time_group"] = df["entry_date"].dt.date
        filename = "trade_history_daily.png"
    elif granularity == "yearly":
        df["time_group"] = df["entry_date"].dt.to_period("Y").astype(str)
        filename = "trade_history_yearly.png"
    else:  # default to monthly
        df["time_group"] = df["entry_date"].dt.to_period("M").astype(str)
        filename = "trade_history_monthly.png"

    # Aggregate and plot
    grouped = df.groupby("time_group").size()

    plt.figure(figsize=(10, 5))
    sns.lineplot(x=grouped.index, y=grouped.values, marker="o")
    plt.title(f"Trade History - {granularity.capitalize()} View")
    plt.xlabel("Date")
    plt.ylabel("Trade Count")
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()

    full_path = os.path.join(STATIC_DIR, filename)
    plt.savefig(full_path)
    plt.close()

    return full_path