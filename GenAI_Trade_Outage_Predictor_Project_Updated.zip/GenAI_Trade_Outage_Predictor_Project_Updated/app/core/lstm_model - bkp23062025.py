import os
import numpy as np
import pandas as pd
import pickle
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import EarlyStopping

MODEL_PATH = "app/models/lstm_model.h5"
SCALER_ENCODER_PATH = "app/models/scaler_encoders.pkl"

def preprocess_data(df):
    df = df.copy()

    if "hour" not in df.columns and "entry_time" in df.columns:
        df["hour"] = pd.to_datetime(df["entry_time"]).dt.hour

    features = ["asset_class", "sub_asset_class", "region", "side", "hour"]
    numeric_cols = ["impacted_trades"]

    label_encoders = {}
    for col in features:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        label_encoders[col] = le

    scaler = MinMaxScaler()
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

    X = df[features].values
    y = df[numeric_cols].values

    # Reshape to [samples, timesteps, features] for LSTM
    X = X.reshape((X.shape[0], 1, X.shape[1]))
    return X, y, scaler, label_encoders

def train_model(preprocessed_df: pd.DataFrame):
    X, y, scaler, label_encoders = preprocess_data(preprocessed_df)

    model = Sequential()
    model.add(LSTM(50, activation='relu', input_shape=(X.shape[1], X.shape[2])))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mean_squared_error')  # use full name

    model.fit(X, y, epochs=20, batch_size=16, verbose=1, callbacks=[
        EarlyStopping(monitor='loss', patience=3)
    ])

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    model.save(MODEL_PATH.replace(".h5", ".keras"))

    return model, scaler, label_encoders

def load_trained_model():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}")
    return load_model(MODEL_PATH, compile=False)  # 🛡️ Safe load

def preprocess_data_for_forecast(df, scaler, label_encoders):
    df = df.copy()
    features = ["asset_class", "sub_asset_class", "region", "side", "hour"]

    for col in features:
        le = label_encoders.get(col)
        if le:
            df[col] = le.transform(df[col].astype(str))
        else:
            raise ValueError(f"Missing label encoder for column: {col}")

    df["impacted_trades"] = scaler.transform(df[["impacted_trades"]])
    X = df[features].values
    return X.reshape((1, X.shape[0], X.shape[1]))  # shape: [1, 24, features]

def forecast(model, base_sequence, hours: int, granularity: str = "hourly"):
    """
    Forecast impacted trades using LSTM model for a given number of hours.

    Args:
        model: Trained LSTM model
        base_sequence: Preprocessed input sequence for prediction
        hours: Number of future hours to forecast
        granularity: "hourly" (list) or "total" (sum only)

    Returns:
        List of hourly predictions or single total value depending on granularity
    """
    predictions = []
    current_seq = base_sequence.copy()

    for i in range(hours):
        pred = model.predict(current_seq, verbose=0)
        predicted_count = max(int(np.round(pred[0][0])), 0)  # Avoid negatives
        predictions.append({
            "hour_offset": i,
            "predicted_impacted_trades": predicted_count
        })

        # Slide window: update hour feature (last column assumed to be hour)
        new_row = current_seq[0, -1].copy()
        new_row[-1] = ((new_row[-1] * 23) + 1) % 24 / 23.0  # cyclic increment (normalized hour)
        current_seq = np.append(current_seq[:, 1:, :], [[new_row]], axis=1)

    if granularity == "total":
        return {
            "total_predicted_impacted_trades": sum(p["predicted_impacted_trades"] for p in predictions)
        }

    return predictions

    return predictions
def save_scaler_and_encoders(scaler, label_encoders):
    with open(SCALER_ENCODER_PATH, "wb") as f:
        pickle.dump({"scaler": scaler, "label_encoders": label_encoders}, f)

def load_scaler_and_encoders():
    if not os.path.exists(SCALER_ENCODER_PATH):
        raise FileNotFoundError(f"Scaler/Encoders not found at {SCALER_ENCODER_PATH}")
    with open(SCALER_ENCODER_PATH, "rb") as f:
        data = pickle.load(f)
    return data["scaler"], data["label_encoders"]