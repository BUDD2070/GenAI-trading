import pandas as pd
import lightgbm as lgb
import pickle
import os
from sklearn.preprocessing import MinMaxScaler

MODEL_PATH = "app/models/lightgbm_model.pkl"
SCALER_PATH = "data/volume_scaler.pkl"

def train_model(df: pd.DataFrame):
    print("🧠 Training LightGBM model with MinMaxScaler...")

    # Required columns
    required_columns = ["asset_class", "sub_asset_class", "region", "side", "hour", "volume"]
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Missing column: {col}")

    # Extract features and target
    features = ["asset_class", "sub_asset_class", "region", "side", "hour"]
    target = "volume"

    X = df[features].copy()
    y = df[[target]].copy()

    # Fit scaler on volume
    scaler = MinMaxScaler()
    y_scaled = scaler.fit_transform(y)

    # Mark categorical columns
    cat_features = ["asset_class", "sub_asset_class", "region", "side"]
    for col in cat_features:
        X[col] = pd.Categorical(X[col])

    # Initialize model
    model = lgb.LGBMRegressor(
        n_estimators=100,
        learning_rate=0.1,
        objective='regression'
    )

    # Fit model
    model.fit(X, y_scaled.ravel())

    # Save model
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)

    # Save scaler
    os.makedirs(os.path.dirname(SCALER_PATH), exist_ok=True)
    with open(SCALER_PATH, "wb") as f:
        pickle.dump(scaler, f)

    print(f"✅ LightGBM model saved to {MODEL_PATH}")
    print(f"✅ Volume scaler saved to {SCALER_PATH}")
    return model