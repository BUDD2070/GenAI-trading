import pandas as pd
from app.schemas.trade_schema import TradeQueryRequest
from fastapi import HTTPException
import os
from datetime import datetime
import holidays

CSV_PATH = "app/config/data/trade_history.csv"
us_holidays = holidays.US()

def search_trades(query: TradeQueryRequest):
    if not os.path.exists(CSV_PATH):
        raise HTTPException(status_code=404, detail="❌ trade_history.csv not found.")

    df = pd.read_csv(CSV_PATH, parse_dates=["entry_date"])

    # ✅ Enforce max data date limit (no future forecasting)
    max_data_date = df["entry_date"].max()
    if query.start_date > max_data_date or query.end_date > max_data_date:
        raise HTTPException(
            status_code=400,
            detail=f"❌ Date range cannot exceed latest available data: {max_data_date.date()}"
        )

    # Filter by date range
    df = df[(df["entry_date"] >= query.start_date) & (df["entry_date"] <= query.end_date)]

    def normalize(val):
        return [val] if isinstance(val, str) else val

    # Optional filters
    filters = {
        "asset_class": normalize(query.asset_class) if query.asset_class else None,
        "sub_asset_class": normalize(query.sub_asset_class) if query.sub_asset_class else None,
        "region": normalize(query.region) if query.region else None,
        "buy_sell": normalize(query.buy_sell) if query.buy_sell else None
    }

    for col, values in filters.items():
        if values:
            df = df[df[col].isin(values)]

    granularity = (query.granularity or "total").lower()
    group_cols = query.group_by if query.group_by else ["asset_class"]

    # ✅ Only check for empty result for total/monthly
    if df.empty and granularity in ["total", "monthly"]:
        return {
            "granularity": granularity,
            "message": "No trades found for given filters and date range.",
            "trade_count": 0,
            "results": []
        }

    # 🟦 TOTAL
    if granularity == "total":
        trade_count = df.shape[0]
        grouped = df.groupby(group_cols).size().reset_index(name="trade_count")
        grouped_info = [
            {
                "group": ", ".join(f"{col}: {row[col]}" for col in group_cols),
                "trade_count": int(row["trade_count"])
            }
            for _, row in grouped.iterrows()
        ]
        return {
            "granularity": "total",
            "total_trade_count": trade_count,
            "grouped_result": grouped_info
        }

    # 🟦 DAILY
    elif granularity == "daily":
        date_range = pd.date_range(query.start_date.date(), query.end_date.date(), freq='D')
        results = []

        for date in date_range:
            date_str = date.strftime("%Y-%m-%d")
            is_weekend = date.weekday() >= 5
            is_holiday = date in us_holidays

            # Subset data for the specific date
            day_df = df[df["entry_date"].dt.date == date.date()]

            if day_df.empty:
                if is_weekend and is_holiday:
                    message = "No trades due to weekend and US holiday (FX allowed)"
                elif is_weekend:
                    message = "No trades due to weekend (FX allowed)"
                elif is_holiday:
                    message = "No trades due to US holiday (FX allowed)"
                else:
                    message = "No trades found"
                results.append({
                    "date": date_str,
                    "trade_count": 0,
                    "message": message
                })
                continue

            # ✅ If holiday or weekend, allow only FX
            if is_weekend or is_holiday:
                if not (day_df["asset_class"] == "FX").any():
                    results.append({
                        "date": date_str,
                        "trade_count": 0,
                        "message": "No trades due to weekend or US holiday (FX allowed)"
                    })
                    continue
                else:
                    day_df = day_df[day_df["asset_class"] == "FX"]

            grouped = day_df.groupby(group_cols).size().reset_index(name="trade_count")
            for _, row in grouped.iterrows():
                results.append({
                    "date": date_str,
                    "group": ", ".join(f"{col}: {row[col]}" for col in group_cols),
                    "trade_count": int(row["trade_count"])
                })

        return {
            "granularity": "daily",
            "daily_summary": results
        }

    # 🟦 MONTHLY
    elif granularity == "monthly":
        df["month"] = df["entry_date"].dt.to_period("M")
        results = []

        grouped = df.groupby(["month"] + group_cols).size().reset_index(name="trade_count")
        for _, row in grouped.iterrows():
            results.append({
                "month": str(row["month"]),
                "group": ", ".join(f"{col}: {row[col]}" for col in group_cols),
                "trade_count": int(row["trade_count"])
            })

        return {
            "granularity": "monthly",
            "monthly_summary": results
        }

    # ❌ Invalid granularity
    else:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid granularity '{granularity}'. Use 'daily', 'monthly', or 'total'."
        )