from typing import Optional, Union, List, Literal
from datetime import datetime
from pydantic import BaseModel, Field, validator
from dateutil import parser as date_parser

# ───────────────────────────────────────────────
# 1. Prediction Request Schema
# ───────────────────────────────────────────────
class PredictionRequest(BaseModel):
    asset_class: str
    sub_asset_class: str
    region: str
    buy_sell: str
    start_date: str  # Format: "YYYY-MM-DD HH:MM:SS"
    end_date: str    # Format: "YYYY-MM-DD HH:MM:SS"
    granularity: Optional[str] = Field(default="hourly", description="Options: hourly, daily, monthly")


# ───────────────────────────────────────────────
# 2. Forecast Request Schema
# ───────────────────────────────────────────────

class ForecastRequest(BaseModel):
    asset_class: Union[str, List[str]] = Field(..., description="Required asset class(es), e.g. 'FX' or ['FX','Equities']")
    sub_asset_class: Optional[Union[str, List[str]]] = Field(None, description="Optional sub-asset class(es)")
    start_date: datetime = Field(..., description="Start of forecast window")
    end_date: datetime = Field(..., description="End of forecast window")
    granularity: Optional[str] = Field(default="hourly", description="'hourly' or 'total'")
    region: Optional[Union[str, List[str]]] = Field(None, description="Region filter(s)")
    buy_sell: Optional[Union[str, List[str]]] = Field(None, description="Side filter(s): Buy/Sell")
    group_by: Optional[List[str]] = Field(None, description="Fields to group results by")

    class Config:
        schema_extra = {
            "example": {
                "asset_class": ["FX"],
                "sub_asset_class": ["GBP/JPY", "USD/EUR"],
                "start_date": "2025-08-10 12:00:00",
                "end_date": "2025-08-10 16:00:00",
                "granularity": "hourly",
                "region": ["APAC", "AMER"],
                "buy_sell": ["Buy", "Sell"],
                "group_by": ["region", "buy_sell"]
            }
        }

    @validator("start_date", "end_date", pre=True)
    def parse_datetime_flexibly(cls, value):
        if isinstance(value, datetime):
            return value
        try:
            return date_parser.parse(str(value).strip())
        except Exception as e:
            raise ValueError(f"❌ Invalid datetime format: {value} — {str(e)}")

    @validator("granularity")
    def validate_granularity(cls, value):
        allowed = {"hourly", "total"}
        if value not in allowed:
            raise ValueError(f"granularity must be one of {allowed}")
        return value

# ───────────────────────────────────────────────
# 3. Feedback Request Schema
# ───────────────────────────────────────────────
class FeedbackRequest(BaseModel):
    timestamp: datetime
    asset_class: str
    sub_asset_class: str
    region: Optional[str]
    buy_sell: Optional[str]
    predicted_value: int
    actual_value: int
    comment: Optional[str] = None
    prediction_id: str
    feedback: str

    @validator("timestamp", pre=True)
    def parse_timestamp(cls, value):
        if isinstance(value, datetime):
            return value
        try:
            return date_parser.parse(str(value).strip())
        except Exception as e:
            raise ValueError(f"❌ Invalid timestamp format: {value} — {str(e)}")


# ───────────────────────────────────────────────
# 4. Trade Query Schema
# ───────────────────────────────────────────────
class TradeQueryRequest(BaseModel):
    start_date: datetime
    end_date: datetime
    asset_class: Optional[str] = None
    sub_asset_class: Optional[str] = None
    region: Optional[str] = None
    buy_sell: Optional[str] = None
    group_by: Optional[List[str]] = None
    granularity: Optional[Literal["daily", "monthly", "total"]] = "total"

    @validator("start_date", "end_date", pre=True)
    def parse_datetime_flexibly(cls, value):
        if isinstance(value, datetime):
            return value
        try:
            return date_parser.parse(str(value).strip())
        except Exception as e:
            raise ValueError(f"❌ Invalid datetime format: {value} — {str(e)}")


# ───────────────────────────────────────────────
# 5. Trade Visualization Schema
# ───────────────────────────────────────────────
class TradeVisualizationRequest(BaseModel):
    start_date: datetime
    end_date: datetime
    asset_class: Optional[str] = None
    sub_asset_class: Optional[str] = None
    region: Optional[str] = None
    buy_sell: Optional[str] = None
    granularity: Optional[Literal["daily", "monthly", "yearly"]] = "monthly"

    @validator("start_date", "end_date", pre=True)
    def parse_dates(cls, value):
        if isinstance(value, datetime):
            return value
        try:
            return date_parser.parse(str(value).strip())
        except Exception as e:
            raise ValueError(f"❌ Invalid date: {value} — {str(e)}")