from fastapi import APIRouter, HTTPException, Body
from app.core.chatbot import handle_natural_language_query
from app.core.lstm_model import load_trained_model
from app.core.preprocess import load_preprocessed_data
from app.core.trades_search import search_trades
from app.core.feedback import log_feedback
from app.core.visualizer import (
    plot_hourly_trend,
    plot_buy_sell_distribution,
    plot_prediction_vs_actual,
    plot_volume_spike,
    plot_trade_history
)
from app.schemas.trade_schema import (
    FeedbackRequest,
    TradeQueryRequest,
    ForecastRequest
)
from app.schemas.trade_schema import TradeVisualizationRequest
import pandas as pd
from datetime import timedelta
import traceback
import os

router = APIRouter()

RAW_DATA_PATH        = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\app\config\data\trade_history.csv"
PREPROCESSED_PATH    = "./data/preprocessed.csv"
MODEL_PATH           = "./app/models/lstm_model.h5"

# ──────────────────────────────────────────────
# 🔮 Forecast API
# ──────────────────────────────────────────────
@router.post("/forecast")
def forecast_route(request: ForecastRequest):
    try:
        df = load_preprocessed_data(PREPROCESSED_PATH)

        for col in ("asset_class", "sub_asset_class", "region", "side"):
            if col in df.columns:
                df[col] = df[col].str.lower()

        valid_cols = {"asset_class", "sub_asset_class", "region", "side", "hour"}
        group_by = []
        if request.group_by:
            for g in request.group_by:
                key = "side" if g.lower() == "buy_sell" else g.lower()
                if key not in valid_cols:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Invalid group_by field '{g}'. Valid options: {sorted(valid_cols)} or 'buy_sell'."
                    )
                group_by.append(key)

        mask = pd.Series(True, index=df.index)

        assets = request.asset_class if isinstance(request.asset_class, list) else [request.asset_class]
        mask &= df["asset_class"].isin([a.lower() for a in assets])

        if request.sub_asset_class:
            subs = request.sub_asset_class if isinstance(request.sub_asset_class, list) else [request.sub_asset_class]
            mask &= df["sub_asset_class"].isin([s.lower() for s in subs])

        if request.region:
            regions = request.region if isinstance(request.region, list) else [request.region]
            mask &= df["region"].isin([r.lower() for r in regions])

        if request.buy_sell:
            sides = request.buy_sell if isinstance(request.buy_sell, list) else [request.buy_sell]
            mask &= df["side"].isin([s.lower() for s in sides])

        hist = df[mask]
        if hist.empty:
            raise HTTPException(404, "No historical data found for those filters.")

        total_hours = int(((request.end_date - request.start_date).total_seconds() // 3600) + 1)

        if group_by and request.granularity == "total":
            gb = hist.groupby(group_by)["impacted_trades"].mean()
            totals = {
                ",".join(k if isinstance(k, tuple) else (k,)): int(round(v * total_hours))
                for k, v in gb.items()
            }
            key = "total_forecasted_trades_by_" + "_and_".join(group_by)
            return {"mode": "forecast", key: totals}

        records = []
        current = request.start_date
        while current <= request.end_date:
            h = current.hour
            slice_ = hist[hist["hour"] == h]
            mean_val = slice_["impacted_trades"].mean()

            if group_by:
                gb_hour = slice_.groupby(group_by)["impacted_trades"].mean()
                for group_vals, v in gb_hour.items():
                    rec = {
                        "timestamp": current.strftime("%Y-%m-%d %H:%M:%S"),
                        "forecasted_trades": int(round(v)) if pd.notna(v) else 0
                    }
                    vals = group_vals if isinstance(group_vals, tuple) else (group_vals,)
                    for col_name, col_val in zip(group_by, vals):
                        rec[col_name] = col_val
                    records.append(rec)
            else:
                records.append({
                    "timestamp": current.strftime("%Y-%m-%d %H:%M:%S"),
                    "forecasted_trades": int(round(mean_val)) if pd.notna(mean_val) else 0
                })

            current += timedelta(hours=1)

        return {"mode": "forecast", "hourly_forecast": records}

    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Forecast failed: {e}")


# ──────────────────────────────────────────────
# 🔎 Trade Search
# ──────────────────────────────────────────────
@router.post("/search-trades")
def search_trades_api(
    query: TradeQueryRequest = Body(
        ..., 
        example={
            "start_date": "2025-06-01 00:00:00",
            "end_date": "2025-06-03 23:59:59",
            "asset_class": "Fixed Income",
            "sub_asset_class": "Treasury Bills",
            "region": "EMEA",
            "buy_sell": "Buy",
            "granularity": "daily",
            "group_by": ["region", "buy_sell"]
        }
    )
):
    try:
        results = search_trades(query)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ──────────────────────────────────────────────
# 💬 Feedback Logging
# ──────────────────────────────────────────────
@router.post("/feedback")
def feedback(request: FeedbackRequest):
    try:
        log_feedback(request.dict())
        return {"status": "Feedback logged"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ──────────────────────────────────────────────
# 📊 Predefined Visualizations
# ──────────────────────────────────────────────
@router.get("/visuals")
def generate_visuals():
    try:
        df = load_preprocessed_data(RAW_DATA_PATH)
        plot_hourly_trend(df)
        plot_buy_sell_distribution(df)
        plot_volume_spike(df)
        plot_prediction_vs_actual(df)
        return {"message": "Visualizations saved in /static/"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ──────────────────────────────────────────────
# 📈 Custom Trade History Visualization
# ──────────────────────────────────────────────
@router.post("/visualize-trades")
def visualize_trade_history(request: TradeVisualizationRequest):
    try:
        df = pd.read_csv(RAW_DATA_PATH, parse_dates=["entry_date"])
        mask = (df["entry_date"] >= request.start_date) & (df["entry_date"] <= request.end_date)

        if request.asset_class:
            mask &= df["asset_class"] == request.asset_class
        if request.sub_asset_class:
            mask &= df["sub_asset_class"] == request.sub_asset_class
        if request.region:
            mask &= df["region"] == request.region
        if request.buy_sell:
            mask &= df["buy_sell"] == request.buy_sell

        filtered = df[mask]

        if filtered.empty:
            raise HTTPException(status_code=404, detail="No trades found for selected filters.")

        img_path = plot_trade_history(filtered, request.granularity)
        return {"message": "✅ Visualization generated", "image_path": img_path}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
# ──────────────────────────────────────────────
# 🔁 Model Retraining Trigger
# ──────────────────────────────────────────────
@router.post("/trigger-retrain")
def retrain_model():
    try:
        os.system("python retrain.py")
        return {"status": "Retraining initiated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))