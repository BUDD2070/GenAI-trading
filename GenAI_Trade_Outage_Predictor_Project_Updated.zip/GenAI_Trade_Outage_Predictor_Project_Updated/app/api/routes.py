from fastapi import APIRouter, HTTPException, Body
import pandas as pd
import os
import traceback
from app.core.chatbot import handle_natural_language_query
from app.core.trades_search import search_trades as core_search_trades
from app.core.feedback import log_feedback
from app.core import forecast_model
from app.schemas.trade_schema import ForecastRequest
from app.core.visualizer import (
    plot_hourly_trend,
    plot_buy_sell_distribution,
    plot_prediction_vs_actual,
    plot_volume_spike,
    plot_trade_history
)
from app.schemas.trade_schema import (
    FeedbackRequest,
    TradeQueryRequest,
    ForecastRequest,
    TradeVisualizationRequest
)

router = APIRouter()

# Paths
RAW_DATA_PATH     = r"E:\GENAI\GenAI_Trade_Outage_Predictor_Project\app\config\data\trade_history.csv"
PREPROCESSED_PATH = "./data/preprocessed.csv"
MODEL_PATH        = "./app/models/lstm_model.h5"

# ──────────────────────────────────────────────
# 🔮 Forecast API
# ──────────────────────────────────────────────
@router.post("/forecast")
async def forecast(request: ForecastRequest):
    # Validate input
    if request.start_date > request.end_date:
        raise HTTPException(status_code=400, detail="start_date must be before end_date")

    try:
        result = forecast_model.forecast_trades(request)
        return {"forecast": result}
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Forecasting error: {str(e)}")
# ──────────────────────────────────────────────
# 🔎 Trade Search API
# ──────────────────────────────────────────────
@router.post("/search-trades")
def search_trades_api(
    query: TradeQueryRequest = Body(
        ...,
        example={
            "start_date": "2025-06-01 00:00:00",
            "end_date": "2025-06-03 23:59:59",
            "asset_class": "Fixed Income",
            "sub_asset_class": "Treasury Bonds",
            "region": "EMEA",
            "buy_sell": "Buy",
            "granularity": "daily",
            "group_by": ["region", "buy_sell"]
        }
    )
):
    try:
        results = core_search_trades(query)
        return results
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

# ──────────────────────────────────────────────
# 📈 Trade History Visualization
# ──────────────────────────────────────────────
@router.post("/visualize-trades")
def visualize_trade_history(request: TradeVisualizationRequest):
    try:
        df = pd.read_csv(RAW_DATA_PATH)
        if not pd.api.types.is_datetime64_any_dtype(df["entry_date"]):
            df["entry_date"] = pd.to_datetime(df["entry_date"])

        mask = (df["entry_date"] >= request.start_date) & (df["entry_date"] <= request.end_date)

        if request.asset_class:
            mask &= df["asset_class"] == request.asset_class
        if request.sub_asset_class:
            mask &= df["sub_asset_class"] == request.sub_asset_class
        if request.region:
            mask &= df["region"] == request.region
        if request.buy_sell:
            mask &= df["buy_sell"] == request.buy_sell

        filtered = df[mask]
        if filtered.empty:
            raise HTTPException(status_code=404, detail="No trades found for selected filters.")

        img_path = plot_trade_history(filtered, request.granularity)
        return {"message": "✅ Visualization generated", "image_path": img_path}

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

# ──────────────────────────────────────────────
# 💬 Feedback Logging
# ──────────────────────────────────────────────
@router.post("/feedback")
def feedback(request: FeedbackRequest):
    try:
        log_feedback(request.dict())
        return {"status": "Feedback logged"}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

# ──────────────────────────────────────────────
# 🔁 Model Retraining API
# ──────────────────────────────────────────────
@router.post("/trigger-retrain")
def retrain_model():
    try:
        os.system("python retrain.py")
        return {"status": "Retraining initiated"}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

# ──────────────────────────────────────────────
# 💬 Natural Language Chatbot API
# ──────────────────────────────────────────────
@router.post("/chat")
def chatbot_query(input: dict = Body(...)):
    try:
        response = handle_natural_language_query(input.get("query", ""))
        return {"response": response}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")
