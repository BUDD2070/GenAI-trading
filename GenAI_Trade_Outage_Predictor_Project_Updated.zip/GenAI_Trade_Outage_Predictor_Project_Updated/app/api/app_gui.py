# app_gui.py

import streamlit as st
from app.core.preprocess import preprocess_data, load_preprocessed_data
from app.core.forecast_model import forecast_trades
from app.core.chat import chat_with_bot  # This will be your LLM-powered chatbot logic
from datetime import datetime

st.set_page_config(page_title="Trade Outage Impact Predictor", layout="wide")

st.title("" GenAI Trade Outage Impact Predictor")

# Upload section
uploaded_file = st.file_uploader("Upload Trade File (CSV)", type=["csv"])

if uploaded_file:
    with open("./data/trade_history.csv", "wb") as f:
        f.write(uploaded_file.read())
    st.success("File uploaded and saved.")
    df = preprocess_data()
    st.dataframe(df.head())

# Forecast section
st.header("Forecast Trades")
with st.form("forecast_form"):
    asset_class = st.text_input("Asset Class (e.g. Fixed Income)", "")
    sub_asset_class = st.text_input("Sub Asset Class", "")
    regions = st.multiselect("Region(s)", options=["EMEA", "AMER", "APAC"])
    buy_sell = st.selectbox("Side (optional)", options=["", "Buy", "Sell"])
    start_date = st.date_input("Start Date")
    end_date = st.date_input("End Date")

    submitted = st.form_submit_button("Forecast")
    if submitted:
        from app.schemas.trade_schema import ForecastRequest
        req = ForecastRequest(
            asset_class=asset_class,
            sub_asset_class=sub_asset_class,
            region=regions,
            buy_sell=buy_sell,
            start_date=datetime.combine(start_date, datetime.min.time()),
            end_date=datetime.combine(end_date, datetime.min.time())
        )

        df_loaded = load_preprocessed_data()
        filtered_df = df_loaded.copy()

        # Apply filters
        filtered_df = filtered_df[
            (filtered_df["asset_class"] == req.asset_class) &
            (filtered_df["sub_asset_class"] == req.sub_asset_class)
        ]
        if req.region:
            filtered_df = filtered_df[filtered_df["region"].isin(req.region)]
        if req.buy_sell:
            filtered_df = filtered_df[filtered_df["side"].str.lower() == req.buy_sell.lower()]

        filtered_df = filtered_df[
            (filtered_df["entry_time"] >= req.start_date) &
            (filtered_df["entry_time"] <= req.end_date)
        ]

        if not filtered_df.empty:
            forecast_output = forecast_trades(filtered_df)
            st.success("Forecast Completed")
            st.write(forecast_output)
        else:
            st.warning("⚠️ No data available for the selected filters.")

# Chatbot section
st.header("Chat with Forecast Bot")

user_prompt = st.text_input("Ask a question about trade impact, downstream, etc.")
if user_prompt:
    response = chat_with_bot(user_prompt)
    st.markdown(f"**Bot:** {response}")