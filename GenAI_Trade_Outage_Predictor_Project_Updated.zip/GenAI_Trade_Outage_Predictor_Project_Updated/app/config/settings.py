# app/config/settings.py

import yaml
import os

class Config:
    def _init_(self, config_file="./config/config.yaml"):
        self.config_file = config_file
        self._load_config()

    def _load_config(self):
        if not os.path.exists(self.config_file):
            raise FileNotFoundError(f"Config file not found: {self.config_file}")
        
        with open(self.config_file, "r") as f:
            data = yaml.safe_load(f)

        # Source details
        self.source_type = data.get("source", {}).get("type", "file")
        self.file_path = data.get("source", {}).get("path")
        self.db_connection = data.get("source", {}).get("connection_string")
        self.db_query = data.get("source", {}).get("query")
        self.api_endpoint = data.get("source", {}).get("endpoint")
        self.cache_host = data.get("source", {}).get("host")
        self.cache_port = data.get("source", {}).get("port")
        self.cache_key = data.get("source", {}).get("key")

        # Model and visual path
        self.model_path = data.get("model", {}).get("save_path", "./app/models/lstm_model.h5")
        self.visual_output_path = data.get("visualization", {}).get("output_path", "./static/")

# Global config instance
config = Config()