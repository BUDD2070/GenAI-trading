from app.core import data_source, preprocess, lstm_model
import pandas as pd
import os
import datetime

def retrain_pipeline():
    print("📥 Loading data from configured source...")
    df = data_source.load_data()  # dynamic: file/db/api/cache

    print("🧹 Running preprocessing...")
    df_clean = preprocess.clean_and_engineer(df)

    print("📊 Generating training data...")
    X, y, scaler = preprocess.generate_features_for_lstm(df_clean)

    print("🧠 Training new LSTM model...")
    model = lstm_model.build_and_train_model(X, y)

    model_path = "app/models/lstm_model.h5"
    model.save(model_path)
    print(f"✅ Model saved to: {model_path}")

    # Optionally, save scaler and preprocessed data for inference
    pd.DataFrame(df_clean).to_csv("data/preprocessed.csv", index=False)

    # Log training session
    with open("training_log.txt", "a") as f:
        f.write(f"{datetime.datetime.now()} - Model retrained - {model_path}\n")

    return True

if _name_ == "_main_":
    retrain_pipeline()