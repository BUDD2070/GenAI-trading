# app/core/feedback.py

import pandas as pd
import os
from datetime import datetime
from app.core.preprocess import preprocess_data
from app.core.lstm_model import train_model

FEEDBACK_LOG = "./data/feedback_log.csv"

def log_feedback(trade_id: str, actual: int, predicted: int, meta: dict):
    feedback_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "trade_id": trade_id,
        "actual": actual,
        "predicted": predicted,
        "error": actual - predicted,
        "region": meta.get("region"),
        "asset_class": meta.get("asset_class"),
        "sub_asset_class": meta.get("sub_asset_class"),
        "side": meta.get("side"),
        "hour": meta.get("hour"),
        "volume": meta.get("volume")
    }

    df = pd.DataFrame([feedback_entry])
    os.makedirs("./data", exist_ok=True)

    if os.path.exists(FEEDBACK_LOG):
        df.to_csv(FEEDBACK_LOG, mode="a", header=False, index=False)
    else:
        df.to_csv(FEEDBACK_LOG, mode="w", index=False)

    return {"status": "Feedback logged", "trade_id": trade_id}

def retrain_from_feedback():
    print("Rebuilding model using feedback and trade history...")

    # Full retraining pipeline
    preprocess_data("./data/trade_history.csv")
    train_model("./data/preprocessed.csv")

    return {"status": "Retrained successfully", "time": datetime.utcnow().isoformat()}