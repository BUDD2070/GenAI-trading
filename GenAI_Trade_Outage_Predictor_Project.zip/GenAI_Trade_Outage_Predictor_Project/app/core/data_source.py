# app/core/data_source.py

import pandas as pd
import os
import requests
import sqlalchemy
import json
import redis

def load_from_file(file_path: str) -> pd.DataFrame:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    if file_path.endswith(".csv"):
        return pd.read_csv(file_path)
    elif file_path.endswith(".parquet"):
        return pd.read_parquet(file_path)
    else:
        raise ValueError("Unsupported file format")

def load_from_db(connection_url: str, query: str) -> pd.DataFrame:
    engine = sqlalchemy.create_engine(connection_url)
    with engine.connect() as conn:
        return pd.read_sql(query, conn)

def load_from_api(api_url: str) -> pd.DataFrame:
    response = requests.get(api_url)
    if response.status_code != 200:
        raise Exception("Failed to fetch from API")
    
    data = response.json()
    return pd.DataFrame(data)

def load_from_cache(redis_url: str, key: str) -> pd.DataFrame:
    r = redis.Redis.from_url(redis_url)
    cached_data = r.get(key)
    if cached_data is None:
        raise ValueError("No data found in cache")
    
    return pd.read_json(cached_data)

def load_data(source_config: dict) -> pd.DataFrame:
    source_type = source_config.get("type")
    
    if source_type == "file":
        return load_from_file(source_config.get("path"))
    elif source_type == "db":
        return load_from_db(source_config.get("connection_url"), source_config.get("query"))
    elif source_type == "api":
        return load_from_api(source_config.get("url"))
    elif source_type == "cache":
        return load_from_cache(source_config.get("redis_url"), source_config.get("key"))
    else:
        raise ValueError(f"Unknown source type: {source_type}")