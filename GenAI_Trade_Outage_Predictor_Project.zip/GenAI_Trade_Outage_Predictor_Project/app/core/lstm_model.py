import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import EarlyStopping
import os

MODEL_PATH = "app/models/lstm_model.h5"

# Initialize scalers
scaler = MinMaxScaler()
label_encoders = {}

def prepare_features(data: pd.DataFrame, sequence_length=24):
    """ Prepare sequences and labels for LSTM model """

    # Encode categorical features
    categorical_cols = ['asset_class', 'sub_asset_class', 'region', 'side']
    for col in categorical_cols:
        if col not in label_encoders:
            le = LabelEncoder()
            data[col] = le.fit_transform(data[col])
            label_encoders[col] = le
        else:
            data[col] = label_encoders[col].transform(data[col])

    # Normalize numeric features
    features = ['asset_class', 'sub_asset_class', 'region', 'side', 'hour']
    scaled_features = scaler.fit_transform(data[features])
    X = []
    y = []

    # Create sequences for LSTM
    for i in range(sequence_length, len(data)):
        X.append(scaled_features[i-sequence_length:i])
        y.append(data['trade_count'].iloc[i])

    return np.array(X), np.array(y)

def build_model(input_shape):
    """ Build and compile LSTM model """
    model = Sequential()
    model.add(LSTM(units=64, activation='relu', input_shape=input_shape))
    model.add(Dense(32, activation='relu'))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

def train_model(preprocessed_path="data/preprocessed.csv", sequence_length=24):
    """ Train and save LSTM model """
    data = pd.read_csv(preprocessed_path)
    data.sort_values(by=['date', 'hour'], inplace=True)

    X, y = prepare_features(data, sequence_length=sequence_length)

    model = build_model(input_shape=(X.shape[1], X.shape[2]))
    es = EarlyStopping(monitor='loss', patience=3, restore_best_weights=True)
    model.fit(X, y, epochs=30, batch_size=16, callbacks=[es], verbose=1)

    # Save model
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    model.save(MODEL_PATH)

    return model

def load_trained_model():
    if os.path.exists(MODEL_PATH):
        return load_model(MODEL_PATH)
    else:
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}")

def predict(input_data: pd.DataFrame, model, granularity: str = "hourly"):
    if granularity == "daily":
        input_data['entry_time'] = pd.to_datetime(input_data['entry_time']).dt.date
    elif granularity == "monthly":
        input_data['entry_time'] = pd.to_datetime(input_data['entry_time']).dt.to_period("M").astype(str)
    else:
        input_data['entry_time'] = pd.to_datetime(input_data['entry_time']).dt.floor("H")

    agg_data = input_data.groupby([
        'asset_class', 'sub_asset_class', 'region', 'side', 'entry_time'
    ]).agg({'trade_id': 'count'}).reset_index()

    # Preprocess to match LSTM input shape (normalize, reshape)
    # Then predict using model
    # For demo, return dummy prediction
    return {"predicted_count": int(agg_data['trade_id'].mean()) + 1}