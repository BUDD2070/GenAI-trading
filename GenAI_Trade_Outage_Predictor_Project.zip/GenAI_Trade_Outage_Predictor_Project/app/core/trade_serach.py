# app/core/trade_search.py

import pandas as pd

def search_trades(
    df: pd.DataFrame,
    start_date: str = None,
    end_date: str = None,
    asset_class: str = None,
    sub_asset_class: str = None,
    region: str = None,
    buy_sell: str = None
) -> pd.DataFrame:
    
    result = df.copy()

    if start_date:
        result = result[result["entry_time"] >= pd.to_datetime(start_date)]
    if end_date:
        result = result[result["entry_time"] <= pd.to_datetime(end_date)]

    if asset_class:
        result = result[result["asset_class"].str.lower() == asset_class.lower()]

    if sub_asset_class:
        result = result[result["sub_asset_class"].str.lower() == sub_asset_class.lower()]

    if region:
        result = result[result["region"].str.lower() == region.lower()]

    if buy_sell:
        result = result[result["buy_sell"].str.lower() == buy_sell.lower()]

    return result