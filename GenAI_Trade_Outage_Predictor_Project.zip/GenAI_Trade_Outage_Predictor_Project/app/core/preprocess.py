# app/core/preprocess.py
import pandas as pd
import numpy as np
from datetime import datetime
import os

def preprocess_data(input_path: str = "./data/trade_history.csv") -> pd.DataFrame:
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")
    
    df = pd.read_csv(input_path, parse_dates=["entry_time"])
    
    # Drop nulls & duplicates
    df = df.drop_duplicates()
    df = df.dropna()

    # Remove parent-linked trades
    if "parent_trade_id" in df.columns:
        df = df[df["parent_trade_id"].isnull()]

    # Feature: hour of entry
    df["hour"] = df["entry_time"].dt.hour
    df["date"] = df["entry_time"].dt.date
    df["day"] = df["entry_time"].dt.day
    df["month"] = df["entry_time"].dt.month

    # Detect volume spikes
    df["volume_zscore"] = (df["volume"] - df["volume"].mean()) / df["volume"].std()
    df["volume_spike"] = df["volume_zscore"].abs() > 2  # Spike if z-score > 2

    # Group & aggregate
    agg_df = df.groupby(
        ["asset_class", "sub_asset_class", "region", "side", "hour"]
    ).agg(
        impacted_trades=("trade_id", "count"),
        avg_volume=("volume", "mean"),
        volume_spike_count=("volume_spike", "sum")
    ).reset_index()

    # Save
    os.makedirs("data", exist_ok=True)
    agg_df.to_csv("./data/preprocessed.csv", index=False)

    return agg_df

def search_trades(query) -> list:
    df = pd.read_csv("./data/trade_history.csv", parse_dates=["entry_time"])
    df = df[
        (df["entry_time"] >= query.start_date) &
        (df["entry_time"] <= query.end_date)
    ]

    if query.asset_class:
        df = df[df["asset_class"] == query.asset_class]
    if query.sub_asset_class:
        df = df[df["sub_asset_class"] == query.sub_asset_class]
    if query.region:
        df = df[df["region"] == query.region]
    if query.side:
        df = df[df["side"] == query.side]

    return df.to_dict(orient="records")