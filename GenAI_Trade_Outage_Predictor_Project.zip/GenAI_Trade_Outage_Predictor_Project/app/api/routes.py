from fastapi import APIRouter, HTTPException
from app.core.lstm_model import predict_trade_impact
from app.core.preprocess import preprocess_data
from app.core.feedback import log_feedback
from app.core.trade_search import search_trades
from app.utils.visualizer import (
    plot_hourly_trend, plot_buy_sell_distribution, plot_prediction_vs_actual, plot_volume_spike
)
import pandas as pd
from app.schemas.trade_schema import PredictionRequest, FeedbackRequest, TradeQueryRequest
import os
from datetime import datetime

router = APIRouter()

DATA_PATH = "./data/preprocessed.csv"
MODEL_PATH = "./app/models/lstm_model.h5"


@router.post("/predict")
def predict(request: PredictionRequest):
    try:
        # Load data and filter by time and features
        df = pd.read_csv(DATA_PATH, parse_dates=["entry_time"])

        start = datetime.strptime(request.start_date, "%Y-%m-%d")
        end = datetime.strptime(request.end_date, "%Y-%m-%d")

        filtered_df = df[
            (df["asset_class"] == request.asset_class) &
            (df["sub_asset_class"] == request.sub_asset_class) &
            (df["region"] == request.region) &
            (df["buy_sell"].str.lower() == request.buy_sell.lower()) &
            (df["entry_time"] >= start) &
            (df["entry_time"] <= end)
        ]

        if filtered_df.empty:
            raise HTTPException(status_code=404, detail="No data found for prediction.")

        prediction = predict_trade_impact(filtered_df, model_path=MODEL_PATH, granularity=request.granularity)

        return {
            "granularity": request.granularity,
            "start_date": request.start_date,
            "end_date": request.end_date,
            "predicted_impacted_trades": int(prediction)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/feedback")
def feedback(request: FeedbackRequest):
    try:
        log_feedback(request.dict())
        return {"status": "Feedback logged"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/visuals")
def generate_visuals():
    try:
        df = pd.read_csv(DATA_PATH, parse_dates=["entry_time"])
        plot_hourly_trend(df)
        plot_buy_sell_distribution(df)
        plot_volume_spike(df)
        plot_prediction_vs_actual(df)
        return {"message": "Visualizations saved in /static/"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/search-trades")
def search_trades_api(query: TradeQueryRequest):
    try:
        df = pd.read_csv(DATA_PATH, parse_dates=["entry_time"])
        filtered = search_trades(
            df,
            query.start_date,
            query.end_date,
            query.asset_class,
            query.sub_asset_class,
            query.region,
            query.buy_sell,
        )
        return filtered.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/trigger-retrain")
def retrain_model():
    try:
        os.system("python retrain.py")
        return {"status": "Retraining initiated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))