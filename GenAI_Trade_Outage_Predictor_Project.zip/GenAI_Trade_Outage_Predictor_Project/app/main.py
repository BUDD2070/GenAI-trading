# app/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router

app = FastAPI(
    title="GenAI Trade Outage Impact Predictor",
    description="Real-time prediction of trades impacted during outages using LSTM, historical trade data, and economic signals.",
    version="1.0.0"
)

# Optional: allow cross-origin requests for frontend or dashboard use
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set allowed domains in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API endpoints
app.include_router(router)