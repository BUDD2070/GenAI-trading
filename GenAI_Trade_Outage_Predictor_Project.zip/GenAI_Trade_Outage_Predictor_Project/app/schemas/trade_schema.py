# app/schemas/trade_schema.py
from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime

class TradeInput(BaseModel):
    asset_class: str
    sub_asset_class: str
    region: str
    side: Literal["Buy", "Sell"]
    entry_time: datetime
    volume: int

class FeedbackInput(BaseModel):
    prediction_input: TradeInput
    actual_impacted_trades: int

class SearchQuery(BaseModel):
    start_date: datetime
    end_date: datetime
    asset_class: Optional[str] = None
    sub_asset_class: Optional[str] = None
    region: Optional[str] = None
    side: Optional[Literal["Buy", "Sell"]] = None
from pydantic import BaseModel
from typing import Literal
from pydantic import BaseModel
class PredictRequest(BaseModel):
    asset_class: str
    sub_asset_class: str
    region: str
    side: str
    granularity: str  # "hour", "day", or "month"
    start_date: str    # Format: "YYYY-MM-DD"
    end_date: str      # Format: "YYYY-MM-DD"